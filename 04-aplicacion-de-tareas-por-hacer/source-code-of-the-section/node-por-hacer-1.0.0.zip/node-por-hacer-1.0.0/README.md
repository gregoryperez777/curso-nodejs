## Aplicación de comandos

Este es el ejercicio del curso


Recuerden instalar los paquetes de node

```
npm install
```