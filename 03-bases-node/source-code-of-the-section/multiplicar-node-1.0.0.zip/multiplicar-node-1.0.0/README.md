

## Multiplicar Console App

Esta es una aplicación para generar archivos de tablas de multiplicar

Ejecutar este comando

```
npm install
```