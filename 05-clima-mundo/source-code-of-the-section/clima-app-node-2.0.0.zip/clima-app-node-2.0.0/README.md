## Aplicación del Clima - Curso Node


Recuerden ejecutar ```npm install``` para las librerías


### Ejemplo:
```
node app -d "San Jose Costa Rica"
```